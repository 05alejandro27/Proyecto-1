package es.iessoterohernandez.daw.endes;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;

public class creadorPdf {
    public static void main(String[] args) {
        String dest = "hola_mundo.pdf";

        try {
            PdfWriter writer = new PdfWriter(dest);
            PdfDocument pdfDoc = new PdfDocument(writer);
            Document document = new Document(pdfDoc);
            document.add(new Paragraph("Hola Mundo"));
            document.close();
            System.out.println("PDF creado: " + dest);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

