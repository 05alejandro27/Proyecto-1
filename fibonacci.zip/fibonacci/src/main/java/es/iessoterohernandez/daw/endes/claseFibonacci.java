package es.iessoterohernandez.daw.endes;
import java.util.Scanner;

public class claseFibonacci {
    long ant = 0, post = 1;
    Scanner sc = new Scanner(System.in);
    
    public void fibonacci() {
        
        System.out.println("¿Cuantos números quieres en la sucesión de fibonacci? ");
        int opt = sc.nextInt();
        
        System.out.println("---------------------------");
        System.out.println("La sucesión de Fibonacci con " + opt + "números es:");
        
        for (int i=0; i<opt; i++) {
            System.out.println(ant);
            post = ant + post;
            System.out.println(post);
            ant = ant + post;
        }
    
    }
}
