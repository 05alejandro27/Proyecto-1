package es.iessoterohernandez.daw.endes;
import es.iessoterohernandez.daw.endes.claseFibonacci;

public class fibonacciMain {
	
	public static void main(String[] args) {

		claseFibonacci f = new claseFibonacci();
		
		f.fibonacci();
		
	}
	
}
